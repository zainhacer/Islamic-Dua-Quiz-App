// Sample Duas Array with Categories
const duas = [
    {
      category: 'morning',
      title: 'Before Sleeping',
      arabic: 'اللّهُمَّ بِاسْمِكَ أَمُوتُ وَأَحْيَا',
      translation: '"O Allah, in Your name, I die and I live."',
      audio: 'dua1.mp3'
    },
    {
      category: 'morning',
      title: 'Before Eating',
      arabic: 'بِسْمِ اللّهِ وَعَلَىٰ بَرَكَةِ اللّهِ',
      translation: '"In the name of Allah, and with the blessings of Allah."',
      audio: 'dua2.mp3'
    },
    {
      category: 'evening',
      title: 'Evening Dua',
      arabic: 'اللّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ شَرِّ مَا خَلَقَتْ',
      translation: '"O Allah, I seek refuge in You from the evil of what You have created."',
      audio: 'dua3.mp3'
    },
    {
      category: 'travel',
      title: 'Dua for Travel',
      arabic: 'اللّهُمَّ مَعَكَ نَذْهَبُ',
      translation: '"O Allah, we travel with Your help."',
      audio: 'dua4.mp3'
    },
    {
      category: 'general',
      title: 'Dua for Protection',
      arabic: 'اللّهُمَّ حَفِظْنِي بِرَحْمَتِكَ',
      translation: '"O Allah, protect me with Your mercy."',
      audio: 'dua5.mp3'
    }
  ];
  
  // Function to Display Duas Based on Category
  function displayDuas(filteredDuas) {
    const duaCardsContainer = document.getElementById('dua-cards');
    duaCardsContainer.innerHTML = '';
  
    filteredDuas.forEach(dua => {
      const duaCard = document.createElement('div');
      duaCard.classList.add('dua-card');
      duaCard.innerHTML = `
        <h2>${dua.title}</h2>
        <p class="arabic">${dua.arabic}</p>
        <p class="translation">${dua.translation}</p>
        <button class="play-audio" data-audio="${dua.audio}">Play</button>
      `;
      duaCardsContainer.appendChild(duaCard);
    });
  }
  
  // Filter Duas by Category
  function filterByCategory(category) {
    const filteredDuas = duas.filter(dua => dua.category === category || category === 'all');
    displayDuas(filteredDuas);
  }
  
  // Event Listener for Audio Play Buttons
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('play-audio')) {
      const audioFile = e.target.getAttribute('data-audio');
      const audio = new Audio(`audio/${audioFile}`);
      audio.play();
    }
  });
  
  // Toggle Dark Mode
  document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
  });
  
  // Quiz Answer Check
  document.getElementById('check-answer').addEventListener('click', () => {
    const userAnswer = document.getElementById('quiz-answer').value.trim().toLowerCase();
    const correctAnswer = "in the name of allah and with the blessings of allah"; // Correct answer for the quiz
  
    const result = document.getElementById('quiz-result');
    if (userAnswer === correctAnswer.toLowerCase()) {
      result.textContent = "Correct! Well done!";
      result.style.color = "green";
    } else {
      result.textContent = "Incorrect. Try again.";
      result.style.color = "red";
    }
  });
  
  // Initial Dua Display
  filterByCategory('all');
  